import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.*;
import java.util.TimeZone;

public class AddImg {
    public static void main(String args[]) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Getting the connection
            String mysqlUrl = "jdbc:mysql://localhost:3306/apotek?serverTimezone=" + TimeZone.getDefault().getID();
            Connection con = DriverManager.getConnection(mysqlUrl, "root", "");
            System.out.println("Connection established......");
            //Creating the Statement
            Statement stmt = con.createStatement();
            //Inserting values
            String query = "INSERT INTO obat(namaOb, gambarOb, stock, harga) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, "URINTER 400 MG 10 KAPSUL");
            FileInputStream fin = new FileInputStream("D:\\COOLYEAH\\PRAK PBO\\proyekakhir\\pictures\\urinter.jpg");
            pstmt.setBinaryStream(2, fin);
            pstmt.setString(3, "5");
            pstmt.setString(4, "55000");
            pstmt.execute();

            System.out.println("Data inserted");
            ResultSet rs = stmt.executeQuery("Select * from obat");
            while (rs.next()) {
                System.out.print("Nama Obat : " + rs.getString("namaOb") + ", ");
                System.out.print("Gambar: " + rs.getBlob("gambarOb") + ", ");
                System.out.print("Stock : " + rs.getInt("stock"));
                System.out.println();
            }
        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }
}
