public class Main {

    public static void main(String[] args) {
        MVCFinal mvcp = new MVCFinal();
    }
}